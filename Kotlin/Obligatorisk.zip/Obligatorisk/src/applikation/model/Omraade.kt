package applikation.model

enum class Omraade{
    STANDARD,
    VIP,
    BØRNE,
    TURNERING
}